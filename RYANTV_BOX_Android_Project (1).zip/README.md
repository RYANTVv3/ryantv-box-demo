# RYANTV BOX

Android WebView wrapper for https://zetastream.fun/

## Build
Open this folder in Android Studio and let Gradle sync, then:
Build > Build Bundle(s) / APK(s) > Build APK(s)

Or push the project to GitHub and run the included **Build RYANTV BOX APK** workflow.

Only package/use a site or content when you have the right to do so.
